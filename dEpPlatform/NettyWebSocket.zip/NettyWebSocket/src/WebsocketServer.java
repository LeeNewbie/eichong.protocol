/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.iminido.netty.helper.ServerInitializer;
import com.iminido.utils.ConfigManager;
import java.net.InetSocketAddress;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.util.concurrent.ImmediateEventExecutor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WebsocketServer {
    
    private static final Logger log = LogManager.getLogger(WebsocketServer.class);
    private final ChannelGroup group = new DefaultChannelGroup(ImmediateEventExecutor.INSTANCE);
    private final EventLoopGroup parentGroup = new NioEventLoopGroup();	
    private final EventLoopGroup workerGroup = new NioEventLoopGroup();	
    private Channel channel;

    public ChannelFuture start(InetSocketAddress address){
        ServerBootstrap boot = new ServerBootstrap();
        
        boot.group(parentGroup, workerGroup).channel(NioServerSocketChannel.class).childHandler(createInitializer(group));
        ChannelFuture f = boot.bind(address).syncUninterruptibly();
        channel = f.channel();
        return f;
    }

    protected ChannelHandler createInitializer(ChannelGroup group) {
        return new ServerInitializer(group);
    }

    public void destroy(){
        if(channel != null)
            channel.close();
        group.close();
        workerGroup.shutdownGracefully();
        parentGroup.shutdownGracefully();
    }

    public static void main(String[] args) {
        final WebsocketServer server = new WebsocketServer();
        
        int configPort = ConfigManager.getConfigValueAsInt("websocket.port");
        int port = configPort == 0 ? 59898 : configPort;
        
        ChannelFuture f = server.start(new InetSocketAddress(port));          
        log.info("websocket start port at {}", port);

        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run() {
                server.destroy();
            }
        });
        f.channel().closeFuture().syncUninterruptibly();
    }
	
}
