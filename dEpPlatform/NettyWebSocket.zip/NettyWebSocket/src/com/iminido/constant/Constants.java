/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iminido.constant;

/**
 *
 * @author Administrator
 */
public class Constants {
    
    public static final int READ_IDEL_TIME_OUT = 10000; // 读超时
    public static final int WRITE_IDEL_TIME_OUT = 15000;// 写超时
    public static final int ALL_IDEL_TIME_OUT = 20000; // 所有超时
    
}
