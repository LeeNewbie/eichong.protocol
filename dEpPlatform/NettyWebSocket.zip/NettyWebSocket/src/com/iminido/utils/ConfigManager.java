/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iminido.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 *
 * @author Administrator
 */
public class ConfigManager {
    
    private static final Logger log = LogManager.getLogger();
    private static final Properties configProps = new Properties();
    
    static {
    	initialize();
    }

    private static void initialize() {
        try {
            String path = "prop/myconf.properties";
            String os = System.getProperty("os.name");
            if (os.toLowerCase().startsWith("win")) {
                path = "/src/prop/myconf.properties";
            }
            InputStream in = new FileInputStream(System.getProperty("user.dir") + File.separator + path);            
            configProps.load(in);
        } catch (Exception e) {
            log.error("读取配置文件出错", e);
        }
    }

    public static String getConfigValue(String configKey) {
        String configValue = (String) configProps.getProperty(configKey);
        return configValue;
    }

    public static int getConfigValueAsInt(String configKey) {
        int intValue = 0;
        try {
            intValue = Integer.parseInt(getConfigValue(configKey));
        } catch (NumberFormatException e) {
            intValue = 0;
        }
        return intValue;
    }

    public static Properties getConfigProps(){
        return configProps;
    }
    
    public static void main(String[] args)
                    throws UnsupportedEncodingException, IOException {
        String x = getConfigValue("sec");
        System.out.println(x);

    }
    
}
