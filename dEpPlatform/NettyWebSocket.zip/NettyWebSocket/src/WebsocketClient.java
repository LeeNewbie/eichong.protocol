/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.http.DefaultHttpHeaders;
import io.netty.handler.codec.http.HttpClientCodec;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketClientHandshakerFactory;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketVersion;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import static java.lang.Thread.sleep;
import java.net.URI;
import java.text.DecimalFormat;
import static java.lang.Thread.sleep;

/**
 *
 * @author Administrator
 */
public class WebsocketClient {
    
    private static final String CID_FORMAT = "0000000";   
    private static final String CID_PREFIX = "1R";
  
    public static String getCidNumber(int index){ 
        DecimalFormat df = new DecimalFormat(CID_FORMAT);          
        String cidSuffix = df.format(index);  
        return cidSuffix;
    }  
    
        
    public static void main(String[] args) throws Exception {
        
        int num = 1000;
        int cidStart =1;
        try{
            num = Integer.valueOf(args[0]); 
            cidStart = Integer.valueOf(args[1]);
        }catch( Exception e) {        
        }
        for(int i=1; i< num; i+=2) {
            String cid = CID_PREFIX + getCidNumber(cidStart);
            cidStart ++;           
            System.out.println("cid: " + cid + "  magic number: " + i);
            String token = "32kmlox";
            String url = "ws://192.168.1.239:7397/?cid="+ cid + "&pn=lftest.2&token=" + token;
            processRequest(url, i);
        }
    }
    
    public static void processRequest(String url, int magicNmuber) throws Exception {
        URI uri = new URI(url);
        String scheme = uri.getScheme() == null? "ws" : uri.getScheme();
        String host = uri.getHost() == null? "127.0.0.1" : uri.getHost();
        int port = uri.getPort();
        if (uri.getPort() == -1) {
            if ("ws".equalsIgnoreCase(scheme)) {
                port = 80;
            } 
        }

        EventLoopGroup group = new NioEventLoopGroup();
        try {         
            final WebSocketClientHandler handler =
                    new WebSocketClientHandler(
                            WebSocketClientHandshakerFactory.newHandshaker(
                                    uri, WebSocketVersion.V13, null, false, new DefaultHttpHeaders()));

            Bootstrap b = new Bootstrap();
            b.group(group)
             .channel(NioSocketChannel.class)
             .handler(new ChannelInitializer<Channel>() {
                 @Override
                 protected void initChannel(Channel ch) {
                     ChannelPipeline p = ch.pipeline();                    
                     p.addLast(
                             new HttpClientCodec(),
                             new HttpObjectAggregator(8192),
                             handler);
                 }
             });

            Channel ch = b.connect(uri.getHost(), port).sync().channel();
            System.out.println("client ip, port: " + ch.localAddress().toString());
            handler.handshakeFuture().sync();

            String msg =  String.format("{\"_\":[3233,2,%d]}", magicNmuber);
            System.out.println("request message: " + msg);
            
            // 如果是单个客户端多次请求，就用while 循环.
            
            WebSocketFrame frame = new TextWebSocketFrame(msg);
            ch.writeAndFlush(frame);
            //sleep(50);
          
        } finally {
           // group.shutdownGracefully();
        }
    }    
    
}
