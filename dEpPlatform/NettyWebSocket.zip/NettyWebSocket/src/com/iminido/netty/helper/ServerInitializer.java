/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iminido.netty.helper;

import com.iminido.constant.Constants;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.group.ChannelGroup;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.stream.ChunkedWriteHandler;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.handler.timeout.ReadTimeoutHandler;
import java.util.concurrent.TimeUnit;

/**
 ** 文件名：ServerInitializer.java
 主要作用：TODO
 */
public class ServerInitializer extends ChannelInitializer<Channel> {

    private final ChannelGroup group;
    public ServerInitializer(ChannelGroup group) {
        super();
        this.group = group;
    }

    @Override
    protected void initChannel(Channel ch) throws Exception {
        
        ChannelPipeline pipeline = ch.pipeline();

        pipeline.addLast(new HttpServerCodec());

        pipeline.addLast(new ChunkedWriteHandler());

        pipeline.addLast(new HttpObjectAggregator(64*1024));
        
        pipeline.addLast("idleTimeoutHandler", new IdleStateHandler(
                                Constants.READ_IDEL_TIME_OUT, Constants.WRITE_IDEL_TIME_OUT,
                                Constants.ALL_IDEL_TIME_OUT, TimeUnit.MILLISECONDS));
        
       // pipeline.addLast(new HeartbeatServerHandler());

        pipeline.addLast(new WebSocketFrameHandler(group));
        
        
       
    }

}
