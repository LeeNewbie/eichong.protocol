/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.iminido.handler;

import io.netty.channel.Channel;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SessionCacheHandler {
    
    private final Logger log = LogManager.getLogger();
	
    private static SessionCacheHandler instance; 
    
    private final ConcurrentHashMap<String, Channel> sessionChannelMap;

    private SessionCacheHandler () {
        sessionChannelMap = new ConcurrentHashMap<String, Channel>();
    } 

    private static class InstanceHolder {
        private static SessionCacheHandler instance = new SessionCacheHandler();
    }    

    public static SessionCacheHandler getInstance(){
        return InstanceHolder.instance ;
    }
    
    public void setSessionChannelCache(String sessionId , Channel channel){
        sessionChannelMap.put(sessionId, channel);
    }
    
    public Channel getSessionChannelCache(String sessionId){
        return sessionChannelMap.get(sessionId);
    }
    
    public void removeSessionChannelCache(String sessionId) {
        sessionChannelMap.remove(sessionId);
    }
    
    public int size() {
        return sessionChannelMap.size();
    }
    
    
    
    
}
