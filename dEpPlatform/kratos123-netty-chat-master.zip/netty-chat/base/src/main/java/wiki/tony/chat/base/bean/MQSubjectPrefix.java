package wiki.tony.chat.base.bean;

/**
 * Created by Tony on 4/14/16.
 */
public class MQSubjectPrefix {

    public static final String MESSAGE = "msg:";

}
