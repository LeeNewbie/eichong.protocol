/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.iminido.netty.helper;

import com.iminido.handler.SessionCacheHandler;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import static io.netty.handler.codec.http.HttpHeaders.isKeepAlive;
import static io.netty.handler.codec.http.HttpHeaders.setContentLength;
import static io.netty.handler.codec.http.HttpResponseStatus.BAD_REQUEST;
import static io.netty.handler.codec.http.HttpVersion.HTTP_1_1;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import io.netty.handler.codec.http.websocketx.CloseWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PingWebSocketFrame;
import io.netty.handler.codec.http.websocketx.PongWebSocketFrame;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerHandshaker;
import io.netty.handler.codec.http.websocketx.WebSocketServerHandshakerFactory;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.util.CharsetUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

/**
 ** 文件名：WebSocketFrameHandler.java
 ** 主要作用：TODO
 */
public class WebSocketFrameHandler extends SimpleChannelInboundHandler<Object> {
	
    private final Logger log = LogManager.getLogger();
    private final ChannelGroup group;
    private WebSocketServerHandshaker handshaker;

    public WebSocketFrameHandler(ChannelGroup group) {
        super();
        this.group = group;
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        // 模拟用户CID. 用远程IP 代替
        String cid = ctx.channel().remoteAddress().toString();
        SessionCacheHandler.getInstance().removeSessionChannelCache(cid);
        log.debug("current size: " + SessionCacheHandler.getInstance().size());
        super.channelInactive(ctx); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        // 模拟用户CID. 用远程IP 代替
        String cid = ctx.channel().remoteAddress().toString();
        SessionCacheHandler.getInstance().setSessionChannelCache(cid, ctx.channel());
        log.debug("current size: " + SessionCacheHandler.getInstance().size());
        super.channelActive(ctx); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if(evt == WebSocketServerProtocolHandler.ServerHandshakeStateEvent.HANDSHAKE_COMPLETE){
            group.add(ctx.channel()); 
        }else{
            super.userEventTriggered(ctx, evt);
        }
    }
    
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
	ctx.flush();
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, Object msg) throws Exception {        
        if (msg instanceof FullHttpRequest) {
            handleHttpRequest(ctx, (FullHttpRequest) msg);
        } else if (msg instanceof WebSocketFrame) {
            handWebSocketFrame(ctx, (WebSocketFrame) msg);
        } else {
            throw new UnsupportedOperationException("Not supported yet.");
        }
    }
    
    private void handWebSocketFrame(ChannelHandlerContext ctx, WebSocketFrame frame) {        
        // 判断是否是关闭链路的指令
        if (frame instanceof CloseWebSocketFrame) {
            handshaker.close(ctx.channel(), (CloseWebSocketFrame) frame.retain());
	    return;
        }        
        // 判断是否是Ping消息
	if (frame instanceof PingWebSocketFrame) {
	    ctx.channel().write(new PongWebSocketFrame(frame.content().retain()));
	    return;
	}
        
	// 处理文本信息
	if (frame instanceof TextWebSocketFrame) {
            processTextRequest(ctx, ((TextWebSocketFrame) frame));
	}
        // 处理二进制.
        if (frame instanceof BinaryWebSocketFrame) {
            BinaryWebSocketFrame binaryFrame = (BinaryWebSocketFrame) frame;
            processBinaryRequest(ctx, binaryFrame);
        }
    }
    
    private void processTextRequest(ChannelHandlerContext ctx, TextWebSocketFrame frame) {
        String request = frame.text();
        log.debug("get client request;【{}】", request);
        JSONObject retObj = new JSONObject();
        try{
            JSONObject params = JSONObject.parseObject(request);
            //retObj = CommandHandler.dispatchMessage(params);
            retObj.put("flag", true).put("data", params.get("name"));
        } catch (Exception e) {
            log.error("处理错误", e);
            retObj.put("flag", false);
        }
        String returnMsg = retObj.toJSONString();  
        log.debug("resonse to client:【{}】", returnMsg);            
        ctx.channel().write(new TextWebSocketFrame(returnMsg));   
    }
    
    private void processBinaryRequest(ChannelHandlerContext ctx, BinaryWebSocketFrame frame) {
    
    }
    
    private void handleHttpRequest(ChannelHandlerContext ctx, FullHttpRequest request) throws Exception {
	// 如果HTTP解码失败，返回HHTP异常
	if (!request.getDecoderResult().isSuccess()
		|| (!"websocket".equals(request.headers().get("Upgrade")))) {
	    sendHttpResponse(ctx, request, new DefaultFullHttpResponse(HTTP_1_1, BAD_REQUEST));
	    return;
	}
	// 构造握手响应返回，本机测试
	WebSocketServerHandshakerFactory wsFactory = new WebSocketServerHandshakerFactory(
		"ws://localhost:8080/ws", null, false);
	handshaker = wsFactory.newHandshaker(request);
	if (handshaker == null) {
	    WebSocketServerHandshakerFactory.sendUnsupportedWebSocketVersionResponse(ctx.channel());
	} else {
	    handshaker.handshake(ctx.channel(), request);
	}
    }

    
    private static void sendHttpResponse(ChannelHandlerContext ctx, FullHttpRequest request, FullHttpResponse response) {
	// 返回应答给客户端
	if (response.getStatus().code() != 200) {
	    ByteBuf buf = Unpooled.copiedBuffer(response.getStatus().toString(),CharsetUtil.UTF_8);
	    response.content().writeBytes(buf);
	    buf.release();
	    setContentLength(response, response.content().readableBytes());
	}
	// 如果是非Keep-Alive，关闭连接
	ChannelFuture f = ctx.channel().writeAndFlush(response);
	if (!isKeepAlive(request) || response.getStatus().code() != 200) {
	    f.addListener(ChannelFutureListener.CLOSE);
	}
    }
    
    
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        ctx.close();
        log.error("连接异常", cause.getMessage());
        cause.printStackTrace();
    }

 
}
