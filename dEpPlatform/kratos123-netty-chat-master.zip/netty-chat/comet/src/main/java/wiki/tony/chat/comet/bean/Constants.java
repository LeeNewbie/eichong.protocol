package wiki.tony.chat.comet.bean;

import io.netty.util.AttributeKey;

/**
 * Created by Tony on 4/14/16.
 */
public class Constants {

    public static final AttributeKey<Long> KEY_USER_ID = AttributeKey.valueOf("user_id");

}
