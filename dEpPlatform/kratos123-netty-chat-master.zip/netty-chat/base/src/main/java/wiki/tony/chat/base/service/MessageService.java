package wiki.tony.chat.base.service;

import wiki.tony.chat.base.bean.Message;

/**
 * Created by Tony on 4/14/16.
 */
public interface MessageService {

    void push(Message msg);

}
